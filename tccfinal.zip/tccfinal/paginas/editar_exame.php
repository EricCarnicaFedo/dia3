<?php
// Inicia a sessão para capturar qualquer mensagem de erro ou sucesso
session_start();

// Inclui o arquivo de conexão com o banco de dados e a classe Exames
require('classeexames.php');

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Captura os dados do formulário
    $exameId = $_POST['exameId'];
    $resultado = $_POST['resultado'];

    // Instancia a classe Exames
    $exame = new Exames();

    // Atualiza o exame no banco de dados
    $resultadoAtualizado = $exame->atualizarResultado($exameId, $resultado);

    // Verifica se a atualização foi bem-sucedida
    if ($resultadoAtualizado) {
        // Mensagem de sucesso
        $_SESSION['message'] = "Exame atualizado com sucesso!";
        header('Location: listar_exames.php'); // Redireciona para a página de listagem de exames
        exit();
    } else {
        // Mensagem de erro
        $_SESSION['error'] = "Erro ao atualizar o exame. Tente novamente!";
        header('Location: listar_exames.php'); // Redireciona para a página de listagem de exames
        exit();
    }
} else {
    // Se a requisição não for POST, redireciona para a página de listagem de exames
    header('Location: pets.php');
    exit();
}
?>
