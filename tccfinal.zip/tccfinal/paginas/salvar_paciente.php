<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tccdois";

// Criando conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturando os valores do formulário
    $nomeAnimal = $_POST['nomeAnimal'] ?? null;
    $especie = $_POST['especie'] ?? null;
    $idade = $_POST['idade'] ?? null;
    $sexo = $_POST['sexo'] ?? null;
    $tutorId = $_POST['tutor'] ?? null;

    // Verificando se todos os campos obrigatórios foram preenchidos
    if (empty($nomeAnimal) || empty($especie) || empty($idade) || empty($sexo)) {
        $_SESSION['message'] = "Todos os campos obrigatórios precisam ser preenchidos!";
        header("Location: formulario_paciente.php");
        exit();
    }

    // Preparando a consulta SQL sem a coluna 'raca'
    $sql = "INSERT INTO pacientes (nome, especie, idade, sexo, tutor_id) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Verificando se a consulta foi preparada corretamente
    if (!$stmt) {
        die("Erro ao preparar consulta: " . $conn->error);
    }

    $stmt->bind_param("ssisi", $nomeAnimal, $especie, $idade, $sexo, $tutorId);

    // Executando a consulta e verificando o resultado
    if ($stmt->execute()) {
        echo "Consulta executada com sucesso!"; // Verifica se a consulta foi executada
        // Verificando se o tutor existe
        $sqlTutor = "SELECT nome FROM clientes WHERE idCliente = ?";
        $stmtTutor = $conn->prepare($sqlTutor);
        $stmtTutor->bind_param("i", $tutorId);
        $stmtTutor->execute();
        $stmtTutor->bind_result($nomeDono);
        $stmtTutor->fetch();
        $stmtTutor->close();

        if ($nomeDono) {
            $_SESSION['message'] = "Paciente adicionado com sucesso! Dono: " . $nomeDono;
        } else {
            $_SESSION['message'] = "Erro: Tutor não encontrado!";
        }
    } else {
        echo "Erro ao executar a consulta: " . $stmt->error; // Mostra qualquer erro gerado
        $_SESSION['message'] = "Erro ao adicionar paciente: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    // Redirecionando para a página após a inserção
    header("Location: adicionarpaciente.php");
    exit();
}
?>
