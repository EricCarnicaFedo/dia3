<?php
require('conexaobd.php'); // Inclua seu arquivo de configuração de banco de dados

if (isset($_POST['idConsulta'])) {
    $idConsulta = $_POST['idConsulta'];

    // Atualizar o status da consulta para 'Realizada'
    $query = "UPDATE consultas_marcadas SET status = 'Realizada' WHERE idConsulta = :idConsulta";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':idConsulta', $idConsulta, PDO::PARAM_INT);

    // Verificar se a consulta foi atualizada com sucesso
    if ($stmt->execute()) {
        echo 'success';
    } else {
        echo 'error';
    }
} else {
    echo 'error';
}
?>
