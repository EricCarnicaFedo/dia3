<?php
include('conexaobd.php'); // Ajuste o caminho conforme necessário

if (isset($_GET['idPaciente'])) {
    $idPaciente = $_GET['idPaciente'];

    try {
        // Iniciar a transação
        $pdo->beginTransaction();

        // Deletar registros relacionados na tabela 'tratamentos'
        $deleteTratamentos = $pdo->prepare("DELETE FROM tratamentos WHERE idPaciente = :idPaciente");
        $deleteTratamentos->bindParam(':idPaciente', $idPaciente, PDO::PARAM_INT);
        $deleteTratamentos->execute();

        // Deletar registros relacionados na tabela 'exames_realizados' (se necessário)
        $deleteExames = $pdo->prepare("DELETE FROM exames_realizados WHERE idPaciente = :idPaciente");
        $deleteExames->bindParam(':idPaciente', $idPaciente, PDO::PARAM_INT);
        $deleteExames->execute();

        // Agora, deletar o paciente
        $deletePaciente = $pdo->prepare("DELETE FROM pacientes WHERE idPaciente = :idPaciente");
        $deletePaciente->bindParam(':idPaciente', $idPaciente, PDO::PARAM_INT);
        $deletePaciente->execute();

        // Confirmar a transação
        $pdo->commit();

        // Retornar sucesso para o cliente
        echo json_encode(['success' => true, 'message' => 'Paciente deletado com sucesso!']);
    } catch (Exception $e) {
        // Reverter a transação em caso de erro
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Erro ao deletar paciente: ' . $e->getMessage()]);
    }

    // Fechar conexões
    $deleteTratamentos = null;
    $deleteExames = null;
    $deletePaciente = null;
    $pdo = null;
}
?>
