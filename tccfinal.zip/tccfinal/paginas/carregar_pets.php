<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tccdois";

// Criando conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

if (isset($_GET['tutor_id'])) {
    $tutorId = $_GET['tutor_id'];
    $query = "SELECT id, nome FROM pets WHERE tutor_id = $tutorId";
    $result = $conn->query($query);

    $pets = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $pets[] = $row;
        }
    }
    
    echo json_encode($pets);
}

$conn->close();
?>
