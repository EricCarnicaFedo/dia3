<?php
// Verifica se o idConsulta foi passado na URL
if (isset($_GET['id'])) {
    // Conecta ao banco de dados (ajuste os detalhes da conexão conforme necessário)
    require("conexaobd.php");

    // Recupera o ID da consulta
    $idConsulta = $_GET['id'];

    // Prepara a consulta SQL para excluir o registro
    $query = "DELETE FROM consultas_marcadas WHERE idConsulta = :idConsulta";
    $stmt = $pdo->prepare($query);

    // Vincula o parâmetro
    $stmt->bindParam(':idConsulta', $idConsulta, PDO::PARAM_INT);

    // Executa a query
    if ($stmt->execute()) {
        // Se a exclusão for bem-sucedida, redireciona de volta para a página de consultas marcadas
        header('Location: agenda.php');
        exit;
    } else {
        // Caso contrário, exibe uma mensagem de erro
        echo "Erro ao excluir consulta.";
    }
}
?>
